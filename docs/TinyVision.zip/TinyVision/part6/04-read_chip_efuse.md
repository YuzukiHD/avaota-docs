---
sidebar_position: 3
---
# read chip efuse示例
