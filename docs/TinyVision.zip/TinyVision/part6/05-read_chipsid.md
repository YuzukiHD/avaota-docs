---
sidebar_position: 3
---
#  read chips id示例
