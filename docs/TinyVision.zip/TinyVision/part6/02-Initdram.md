---
sidebar_position: 3
---
# Init DRAM示例
